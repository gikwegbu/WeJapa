export default {
    developer: {},
    jobs: [ ],

    bids: [], 
}